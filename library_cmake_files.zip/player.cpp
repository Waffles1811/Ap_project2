#include "player.h"

using namespace dj;
player::player() : x_coord(200), y_coord(200), y_speed(700), isLanded(false), movingRight(false), movingLeft(false) {}

player::player(double xCoord, double yCoord)
    : x_coord(xCoord), y_coord(yCoord), y_speed(700), isLanded(false), movingRight(false), movingLeft(false) {}

double player::getYSpeed() const { return y_speed; }

double player::getXCoord() const { return x_coord; }

double player::getYCoord() const { return y_coord; }

void player::time_up(float time) {
    if (isLanded) {
        goUp(700); // jumps if the player is standing on a platform
    }
    y_coord += y_speed * time;
    if (!isLanded) {
        y_speed -= 850 * time; // applies gravity to the speed
    }
    if (movingLeft) {
        x_coord -= 300 * time;
    } else if (movingRight) {
        x_coord += 300 * time;
    }
}

void player::goRight() { movingRight = true; }

void player::goLeft() { movingLeft = true; }

void player::stopRight() { movingRight = false; }

void player::stopLeft() { movingLeft = false; }

void player::goUp(int acceleration) {
    y_speed += acceleration;
    isLanded = false;
}

void player::landed() {
    y_speed = 0;
    isLanded = true;
}

void player::left() { isLanded = false; }
