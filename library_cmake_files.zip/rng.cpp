#include "rng.h"
int dj::rng::generateRandomint(int min, int max) {
    if (min == max) {
        return min; // otherwise it will try to divide by 0 later
    }
    auto now = std::chrono::high_resolution_clock::now().time_since_epoch().count();
    srand(unsigned (int(now)));
    int retVal = rand();
    retVal = retVal % (max - min);
    retVal += min;
    return retVal;
}
