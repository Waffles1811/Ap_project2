#include "platform.h"

using namespace dj;
platform::platform(double xCoord, double yCoord)
    : x_coord(xCoord), y_coord(yCoord), platformBonus(nullptr), jumpedOn(false) {
    // std::cout << "platform constructed at: " << y_coord << std::endl;
}

platform::~platform() {
    // std::cout << "platform destructed at: " << y_coord << std::endl;
}

void platform::time_up(float time) {
    if (platformBonus) {
        platformBonus->time_up(time); // times up the bonus
    }
}

double platform::getXCoord() const { return x_coord; }

double platform::getYCoord() const { return y_coord; }

double platform::getOffset() const { return 0; }

std::shared_ptr<bonus> platform::getBoost() const { return platformBonus; }

bool platform::getjumpedOn() const { return jumpedOn; }

void platform::setBonus(std::shared_ptr<bonus> _bonus) { platformBonus = std::move(_bonus); }

void platform::landed(int playerXCoord) {
    if (platformBonus and playerXCoord +  80 > x_coord + platformBonus->getXOffset() and
        playerXCoord + 20 < x_coord + platformBonus->getXOffset() + 50) {
        // if there is a bonus on this platform it is activated
        platformBonus->activateBonus();
    }
    jumpedOn = true;
}

void platform::move(int newX, int newY) {
    x_coord = newX;
    y_coord = newY;
}

bool platform::checkOnScreen(int height) const {
    if ((platformBonus and y_coord - height < -50) or (!platformBonus and y_coord - height < 0)) {
        return false;
    }
    return true;
}

static_pf::static_pf(double xCoord, double yCoord) : platform(xCoord, yCoord) {}

int static_pf::getType() const { return 1; }

horizontal_pf::horizontal_pf(double xCoord, double yCoord) : platform(xCoord, yCoord), speed(100), offset(0) {}

double horizontal_pf::getOffset() const { return offset; }

void horizontal_pf::time_up(float time) {
    x_coord += speed * time; // moves the platform
    offset += speed * time;
    if ((offset < -100 and speed < 0) or (offset > 100 and speed > 0)) {
        speed = -speed; // if the offsets gets too high or low, the platforms turns around
    }
    if (platformBonus) {
        platformBonus->time_up(time);
    }
}

int horizontal_pf::getType() const { return 2; }

vertical_pf::vertical_pf(double xCoord, double yCoord) : platform(xCoord, yCoord), speed(100), offset(0) {}

double vertical_pf::getOffset() const { return offset; }

void vertical_pf::time_up(float time) {
    y_coord += speed * time; // moves the platform
    offset += speed * time;
    if ((offset < -100 and speed < 0) or (offset > 100 and speed > 0)) {
        speed = -speed; // if the offsets gets too high or low, the platforms turns around
    }
    if (platformBonus) {
        platformBonus->time_up(time);
    }
}

bool vertical_pf::checkOnScreen(int height) const {
    if ((y_coord - offset + 100 - height < 0 and !platformBonus) or
        (y_coord - offset + 100 - height < -50 and platformBonus)) {
        return false; // returns false if it's origin + the highest allowed offset is below the screen
    }
    return true;
}

int vertical_pf::getType() const { return 3; }

temp_pf::temp_pf(double xCoord, double yCoord) : platform(xCoord, yCoord) {}

int temp_pf::getType() const { return 4; }
