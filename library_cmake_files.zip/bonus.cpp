//
// Created by jensp on 30/12/2024.
//
#include "bonus.h"
using namespace dj;
bonus::bonus(int xCoord, std::shared_ptr<player> _player) : x_coord_offset(xCoord), thePlayer(std::move(_player)) {}

int bonus::getXOffset() const { return x_coord_offset; }

void bonus::time_up(float time) {}

bool bonus::isWorking() { return false; }

spring::spring(int xCoord, std::shared_ptr<player> _player) : bonus(xCoord, std::move(_player)) {}

spring::~spring() {}

void spring::activateBonus() {
    thePlayer->goUp(1673); // launches the player (should be ~2.24 the usual jump height)
}

int spring::getType() const { return 5; }
jetpack::jetpack(int xCoord, std::shared_ptr<player> _player)
    : bonus(xCoord, std::move(_player)), remainingFuelTime(0) {}

jetpack::~jetpack() {}

void jetpack::activateBonus() {
    remainingFuelTime = 3; // sets this variable to 3 meaning it will be active for 3 seconds
    thePlayer->goUp(2000); // launches the player at a speed of 2000
}
void jetpack::time_up(float time) {
    if (remainingFuelTime > 0) {
        remainingFuelTime -= time;   // substract time from the timer
        thePlayer->goUp(800 * time); // offsets gravity so player keeps going up;
    }
}

int jetpack::getType() const { return 6; }

bool jetpack::isWorking() {
    if (remainingFuelTime < 0.0001) { // small offset because it's a float
        return false;                 // returns false if the timer has run out or was never activated
    }
    return true;
}