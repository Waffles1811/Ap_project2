//
// Created by jensp on 31/12/2024.
//

#include "BG_tile.h"

using namespace dj;
BG_tile::BG_tile(int x, int y) : x_coord(x), y_coord(y) {}

int BG_tile::getXCoord() const { return x_coord; }
int BG_tile::getYCoord() const { return y_coord; }
void BG_tile::relativeMove(int xValue, int yValue) {
    x_coord += xValue;
    y_coord += yValue;
}
void BG_tile::absoluteMove(int newX, int newY) {
    x_coord = newX;
    y_coord = newY;
}
void BG_tile::time_up(int height) {
    if (y_coord < height) {   // if the tile is under the screen it is moved up to above the screen
        relativeMove(0, 925); // so the same tiles can be reused indefinitely
    }
}
