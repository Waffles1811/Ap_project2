#include "entity_factory.h"
using namespace dj;
void platformFactory::addBonus(std::shared_ptr<platform> newPlatform, rngFactory& randomNumber,
                               std::shared_ptr<player> Player) {
    int random = randomNumber.getRNG()->generateRandomint(1, 51);
    if (random == 1) { // 2% chance for a platform to have a bonus
        if (randomNumber.getRNG()->generateRandomint(1, 4) != 1) {
            springFactory newSpringFactory;
            newPlatform->setBonus(
                newSpringFactory.createBonusItem(randomNumber.getRNG()->generateRandomint(0, 51), Player));

        } else {
            jetpackFactory newJetpackFactory;
            newPlatform->setBonus(
                newJetpackFactory.createBonusItem(randomNumber.getRNG()->generateRandomint(0, 51), Player));
        }
    }
}

std::pair<int, int> platformFactory::calcCoordinates(int estheight, int type,
                                                     std::vector<std::shared_ptr<platform>> platforms,
                                                     rngFactory& randomNumber) {
    bool found_coordinates = false;
    bool accessible = true;
    int index = 0;
    int x_coord;
    int y_coord;
    while (!((accessible and found_coordinates) or (index > 100 and accessible))) {
        index++;
        accessible = false;
        found_coordinates = true;
        x_coord = randomNumber.getRNG()->generateRandomint(0, 584);
        y_coord = estheight + randomNumber.getRNG()->generateRandomint(-50, 50);
        switch (type) {
        case 2:
            for (auto i : platforms) {
                if (i->getType() == 1 or i->getType() == 4) {
                    if ((i->getXCoord() < x_coord + 215 and i->getXCoord() + 115 > x_coord - 100) and
                        (i->getYCoord() > y_coord - 23 and i->getYCoord() - 23 < y_coord)) {
                        found_coordinates = false;
                        break;
                    }

                    if ((i->getXCoord() - (x_coord + 133) < 310 or x_coord - (i->getXCoord() + 133) < 310) and
                        y_coord - i->getYCoord() < 250) {
                        accessible = true;
                    }
                }
                if (i->getType() == 2) {
                    if ((i->getXCoord() - i->getOffset() - 100 < x_coord + 215 and
                         i->getXCoord() - i->getOffset() + 100 + 115 > x_coord - 100) and
                        (i->getYCoord() > y_coord - 23 and i->getYCoord() - 23 < y_coord)) {
                        found_coordinates = false;
                        break;
                    }

                    if (((i->getXCoord() - i->getOffset()) - (x_coord + 133) < 310 or
                         x_coord - ((i->getXCoord() - i->getOffset()) + 133) < 310) and
                        y_coord - i->getYCoord() < 250) {
                        accessible = true;
                    }
                }

                if (i->getType() == 3) {
                    if ((i->getXCoord() < x_coord + 115 and i->getXCoord() + 115 > x_coord - 100) and
                        (i->getYCoord() - i->getOffset() + 100 > y_coord - 23 and
                         i->getYCoord() - i->getOffset() - 100 - 23 < y_coord)) {
                        found_coordinates = false;
                        break;
                    }

                    if ((i->getXCoord() - (x_coord + 133) < 310 or x_coord - (i->getXCoord() + 133) < 310) and
                        y_coord - (i->getYCoord() - i->getOffset()) < 250) {
                        accessible = true;
                    }
                }
            }
            break;

        case 3:
            for (auto i : platforms) {
                if (i->getType() == 1 or i->getType() == 4) {
                    if ((i->getXCoord() < x_coord + 115 and i->getXCoord() + 115 > x_coord) and
                        (i->getYCoord() > y_coord - 100 - 23 and i->getYCoord() - 23 < y_coord + 100)) {
                        found_coordinates = false;
                        break;
                    }

                    if ((i->getXCoord() - (x_coord + 133) < 310 or x_coord - (i->getXCoord() + 133) < 310) and
                        y_coord - i->getYCoord() < 250) {
                        accessible = true;
                    }

                }

                else if (i->getType() == 2) {
                    if ((i->getXCoord() - 100 < x_coord + 115 and i->getXCoord() + 100 + 115 > x_coord) and
                        (i->getYCoord() > y_coord - 100 - 23 and i->getYCoord() - 23 < y_coord + 100)) {
                        found_coordinates = false;
                        break;
                    }

                    if (((i->getXCoord() - i->getOffset()) - (x_coord + 133) < 310 or
                         x_coord - ((i->getXCoord() - i->getOffset()) + 133) < 310) and
                        y_coord - i->getYCoord() < 250) {
                        accessible = true;
                    }
                }

                if (i->getType() == 3) {
                    if ((i->getXCoord() < x_coord + 115 and i->getXCoord() + 115 > x_coord) and
                        (i->getYCoord() > y_coord - 100 - 23 and i->getYCoord() - 23 < y_coord + 100)) {
                        found_coordinates = false;
                        break;
                    }
                }

                if ((i->getXCoord() - (x_coord + 133) < 310 or x_coord - (i->getXCoord() + 133) < 310) and
                    y_coord - (i->getYCoord() - i->getOffset()) < 250) {
                    accessible = true;
                }
            }

            break;

        default:
            for (auto i : platforms) {
                if (i->getType() == 1 or i->getType() == 4) {
                    if ((i->getXCoord() < x_coord + 115 and i->getXCoord() + 115 > x_coord) and
                        (i->getYCoord() > y_coord - 23 and i->getYCoord() - 23 < y_coord)) {
                        found_coordinates = false;
                        break;
                    }

                    if ((i->getXCoord() - (x_coord + 133) < 310 or x_coord - (i->getXCoord() + 133) < 310) and
                        y_coord - i->getYCoord() < 250) {
                        accessible = true;
                    }
                }
                if (i->getType() == 2) {
                    if ((i->getXCoord() - i->getOffset() - 100 < x_coord + 115 and
                         i->getXCoord() - i->getOffset() + 100 + 115 > x_coord) and
                        (i->getYCoord() > y_coord - 23 and i->getYCoord() - 23 < y_coord)) {
                        found_coordinates = false;
                        break;
                    }

                    if (((i->getXCoord() - i->getOffset()) - (x_coord + 133) < 310 or
                         x_coord - ((i->getXCoord() - i->getOffset()) + 133) < 310) and
                        y_coord - i->getYCoord() < 250) {
                        accessible = true;
                    }
                }
                if (i->getType() == 3) {
                    if ((i->getXCoord() < x_coord + 115 and i->getXCoord() + 115 > x_coord) and
                        (i->getYCoord() - i->getOffset() + 100 > y_coord - 23 and
                         i->getYCoord() - i->getOffset() - 123 < y_coord)) {
                        found_coordinates = false;
                        break;
                    }
                }

                if ((i->getXCoord() - (x_coord + 133) < 310 or x_coord - (i->getXCoord() + 133) < 310) and
                    y_coord - (i->getYCoord() - i->getOffset()) < 250) {
                    accessible = true;
                }
            }
            break;
        }
    }
    return {x_coord, y_coord};
}

std::shared_ptr<player> playerFactory::createPlayer() { return std::make_shared<player>(); }

std::shared_ptr<platform> staticPlatformFactory::createPlatform(int estheight,
                                                                std::vector<std::shared_ptr<dj::platform>> platforms,
                                                                rngFactory& randomNumber,
                                                                std::shared_ptr<player> Player) {
    std::pair<int, int> coordinates = calcCoordinates(estheight, 1, platforms, randomNumber);
    std::shared_ptr<platform> newplatform =
        std::shared_ptr<static_pf>(new static_pf(coordinates.first, coordinates.second));
    addBonus(newplatform, randomNumber, Player);
    return newplatform;
}

std::shared_ptr<platform> horizontalPlatformFactory::createPlatform(int estheight,
                                                                    std::vector<std::shared_ptr<platform>> platforms,
                                                                    rngFactory& randomNumber,
                                                                    std::shared_ptr<player> Player) {
    std::pair<int, int> coordinates = calcCoordinates(estheight, 2, platforms, randomNumber);
    std::shared_ptr<platform> newplatform =
        std::shared_ptr<horizontal_pf>(new horizontal_pf(coordinates.first, coordinates.second));
    addBonus(newplatform, randomNumber, Player);
    return newplatform;
}

std::shared_ptr<platform> verticalPlatformFactory::createPlatform(int estheight,
                                                                  std::vector<std::shared_ptr<platform>> platforms,
                                                                  rngFactory& randomNumber,
                                                                  std::shared_ptr<player> Player) {
    std::pair<int, int> coordinates = calcCoordinates(estheight, 3, platforms, randomNumber);
    std::shared_ptr<platform> newplatform =
        std::shared_ptr<vertical_pf>(new vertical_pf(coordinates.first, coordinates.second));
    addBonus(newplatform, randomNumber, Player);
    return newplatform;
}

std::shared_ptr<platform> temporaryPlatformFactory::createPlatform(int estheight,
                                                                   std::vector<std::shared_ptr<platform>> platforms,
                                                                   rngFactory& randomNumber,
                                                                   std::shared_ptr<player> Player) {
    std::pair<int, int> coordinates = calcCoordinates(estheight, 4, platforms, randomNumber);
    std::shared_ptr<platform> newplatform =
        std::shared_ptr<temp_pf>(new temp_pf(coordinates.first, coordinates.second));
    addBonus(newplatform, randomNumber, Player);
    return newplatform;
}

std::shared_ptr<player> startLocationPlayerFactory::createPlayer() { return std::make_shared<player>(200, 0); }

std::shared_ptr<BG_tile> backgroundFactory::createBackgroundTile(int x_coord, int y_coord) {
    return std::make_shared<BG_tile>(x_coord, y_coord);
}

std::shared_ptr<bonus> springFactory::createBonusItem(int x_coord, std::shared_ptr<player> player) {
    return std::make_shared<spring>(x_coord, player);
}

std::shared_ptr<bonus> jetpackFactory::createBonusItem(int x_coord, std::shared_ptr<player> player) {
    return std::make_shared<jetpack>(x_coord, player);
}
