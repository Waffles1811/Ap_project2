#include "world.h"

using namespace dj;

World::World() : height(0), lastPlatforms(0), difficulty(1), score(0), heightScore(0) {
    startLocationPlayerFactory startPlayerFactory;
    backgroundFactory backgroundTilesFactory;
    Player = startPlayerFactory.createPlayer();
    for (int i = 0; i < 37; i++) {
        for (int j = 0; j < 28; j++) {
            BG_tiles.push_back(
                    backgroundTilesFactory.createBackgroundTile(700 / 28 * j,
                                                                900 / 36 * i)); // spawns all background tiles
        }
    }

    platformFactories.push_back(std::unique_ptr<staticPlatformFactory>(new staticPlatformFactory()));
    platformFactories.push_back(std::unique_ptr<horizontalPlatformFactory>(new horizontalPlatformFactory()));
    platformFactories.push_back(std::unique_ptr<verticalPlatformFactory>(new verticalPlatformFactory()));
    platformFactories.push_back(std::unique_ptr<temporaryPlatformFactory>(new temporaryPlatformFactory()));

    platforms.push_back(std::unique_ptr<platform>(new static_pf(200, 50)));

    makeNewPlatforms(300);
    makeNewPlatforms(500);
    makeNewPlatforms(700);
    makeNewPlatforms(900);
    makeNewPlatforms(1100);
    // makeNewPlatforms(1300);
}

std::vector<std::shared_ptr<platform>> World::getPlatforms() { return platforms; }

std::shared_ptr<player> World::getPlayer() { return Player; }

std::vector<std::shared_ptr<BG_tile>> World::getbackground() { return BG_tiles; }

int World::getScore() { return score; }

int World::getHeight() const { return height; }

void World::landedCheck(float time) {
    if (Player->getYSpeed() >= 0) {
        return; // player can't land if they are still going up
    }
    for (auto &i: platforms) {
        if (i->getXCoord() < Player->getXCoord() + 70 and i->getXCoord() + 85 > Player->getXCoord()) {
            if (i->getYCoord() < Player->getYCoord() - 133.2 and
                i->getYCoord() > Player->getYCoord() - 134 + Player->getYSpeed() * time and
                (Player->getYCoord() > 0 or i->getType() == 3)) {
                if (i->getjumpedOn()) { // score id deducted if you jump twice on the same platform
                    score - 25;
                }
                Player->landed();
                i->landed(Player->getXCoord());
                if (i->getBoost()) {
                    if (i->getBoost()->getType() == 5) { // if platform has a bonus item score is added
                        score += 25;
                    } else {
                        score += 50;
                    }
                }
                if (i->getType() == 4) {
                    i->move(0, -100); // moves the white platform under the screen so a jetpack that is on the platform
                    // isn't deleted but it looks like its deleted
                }
                return;
            }
        }
    }
}

void World::timeUp(float time) {
    landedCheck(time);
    for (auto &i: BG_tiles) {
        i->time_up(height);
    }
    for (int i = platforms.size() - 1; i >= 0; i--) { // times up the platforms
        platforms[i]->time_up(time); // this could work with multithreading but I think the functions is too short
        if (!platforms[i]->checkOnScreen(height)) {
            platforms.erase(platforms.begin() + i); // deletes the pointer and platform
        }
    }
    Player->time_up(time);
    updateWorldHeight();                                               // updates height
    if ((Player->getYCoord() - 133.2) / 20 > heightScore) {            // adds the height aspect of the score
        score += (((Player->getYCoord() - 133.2) / 20 - heightScore)); // the height of the score is the heighest point
        heightScore = (Player->getYCoord() - 133.2) / 20;              // the feet of the player have reached
    }

    switch (difficulty) {
        case 1:
            if (height - lastPlatforms > 150) { // makes new platform every 100 height
                lastPlatforms = height;
                makeNewPlatforms(height + 975);
            }
            break;
        case 2:
            if (height - lastPlatforms > 175) { // makes new platform every 150 height
                lastPlatforms = height;
                makeNewPlatforms(height + 975);
            }
            break;
        case 3:
            if (height - lastPlatforms > 200) { // makes new platform every 200 height
                lastPlatforms = height;
                makeNewPlatforms(height + 975);
            }
            break;
        case 4:
            if (height - lastPlatforms > 225) { // makes new platform every 250 height
                lastPlatforms = height;
                makeNewPlatforms(height + 975);
            }
            break;
        case 5:
            if (height - lastPlatforms > 200) { // makes new platform every 275 height
                lastPlatforms = height;
                makeNewPlatforms(height + 975);
            }
            break;
    }
}

void World::updateWorldHeight() {
    if (Player->getYCoord() - height > 450) {
        height = Player->getYCoord() - 450;
        // difficulty = std::min(int(std::floor((height)/7500)+1), 5);
        // std::cout << difficulty << std::endl;
    }
}

void World::makeNewPlatforms(int estimatedHeight) {
    int maxAmountOfPlatforms;
    switch (difficulty) {
        case 1:
            maxAmountOfPlatforms = 3;
            break;
        case 2:
            maxAmountOfPlatforms = 3;
            break;
        case 3:
            maxAmountOfPlatforms = 2;
            break;
        case 4:
            maxAmountOfPlatforms = 2;
            break;
        case 5:
            maxAmountOfPlatforms = 1;
            break;
    }
    int amount =
            randomNumber->getRNG()->generateRandomint(std::max(1, maxAmountOfPlatforms - 1), maxAmountOfPlatforms + 1);
    for (int i = 0; i < amount; i++) {
        int type;

        int typeRandom = randomNumber->getRNG()->generateRandomint(1, 21);
        switch (difficulty) {
            case 1:
                if (typeRandom < 15) { // 70%
                    type = 1;
                } else if (typeRandom == 15) { // 5%
                    type = 2;
                } else if (typeRandom == 16) { // 5%
                    type = 3;
                } else { // 20%
                    type = 4;
                }
                break;

            case 2:
                if (typeRandom < 13) { // 60%
                    type = 1;
                } else if (typeRandom < 15) { // 10%
                    type = 2;
                } else if (typeRandom < 17) { // 10%
                    type = 3;
                } else { // 20%
                    type = 4;
                }
                break;

            case 3:
                if (typeRandom < 7) { // 30%
                    type = 1;
                } else if (typeRandom < 11) { // 20%
                    type = 2;
                } else if (typeRandom < 15) { // 20%
                    type = 3;
                } else { // 30%
                    type = 4;
                }
                break;

            case 4:
                if (typeRandom < 3) { // 10%
                    type = 1;
                } else if (typeRandom < 9) { // 30%
                    type = 2;
                } else if (typeRandom < 15) { // 30%
                    type = 3;
                } else { // 30%
                    type = 4;
                }
                break;

            case 5:
                if (typeRandom == 1) { // 5%
                    type = 1;
                } else if (typeRandom < 9) { // 35%
                    type = 2;
                } else if (typeRandom < 15) { // 30%
                    type = 3;
                } else { // 30%
                    type = 4;
                }
                break;
        }
        platforms.push_back(
                platformFactories[type - 1]->createPlatform(estimatedHeight, platforms, *randomNumber, Player));
    }
}
